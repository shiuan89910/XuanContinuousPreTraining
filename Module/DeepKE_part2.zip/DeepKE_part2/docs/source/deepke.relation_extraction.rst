Relation Extraction
===================


.. toctree::
   :maxdepth: 4

   deepke.relation_extraction.document
   deepke.relation_extraction.few_shot
   deepke.relation_extraction.standard
   deepke.relation_extraction.multimodal

