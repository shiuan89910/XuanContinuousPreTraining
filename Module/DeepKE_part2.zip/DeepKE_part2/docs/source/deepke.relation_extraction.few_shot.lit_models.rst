Lit Models
==========

deepke.relation\_extraction.few\_shot.lit\_models.base module
-------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.lit_models.base
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.few\_shot.lit\_models.transformer module
--------------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.lit_models.transformer
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.few\_shot.lit\_models.util module
-------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.lit_models.util
   :members:
   :undoc-members:
   :show-inheritance:

