Tools
=====

deepke.name\_entity\_re.standard.tools.dataset module
-----------------------------------------------------

.. automodule:: deepke.name_entity_re.standard.tools.dataset
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.standard.tools.preprocess module
--------------------------------------------------------

.. automodule:: deepke.name_entity_re.standard.tools.preprocess
   :members:
   :undoc-members:
   :show-inheritance:

