Modules
=======

deepke.name\_entity\_re.multimodal.modules.dataset module
---------------------------------------------------------

.. automodule:: deepke.name_entity_re.multimodal.modules.dataset
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.multimodal.modules.train module
-------------------------------------------------------

.. automodule:: deepke.name_entity_re.multimodal.modules.train
   :members:
   :undoc-members:
   :show-inheritance:

