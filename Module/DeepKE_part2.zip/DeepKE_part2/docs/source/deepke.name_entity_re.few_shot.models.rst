Models
======

deepke.name\_entity\_re.few\_shot.models.model module
-----------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.models.model
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.few\_shot.models.modeling\_bart module
--------------------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.models.modeling_bart
   :members:
   :undoc-members:
   :show-inheritance:

