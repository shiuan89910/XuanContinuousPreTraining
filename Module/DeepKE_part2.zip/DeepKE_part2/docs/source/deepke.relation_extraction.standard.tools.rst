Tools
=====


deepke.relation\_extraction.standard.tools.dataset module
---------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.dataset
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.tools.loss module
------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.loss
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.tools.metrics module
---------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.metrics
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.tools.preprocess module
------------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.preprocess
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.tools.serializer module
------------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.serializer
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.tools.trainer module
---------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.trainer
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.tools.vocab module
-------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.tools.vocab
   :members:
   :undoc-members:
   :show-inheritance:

