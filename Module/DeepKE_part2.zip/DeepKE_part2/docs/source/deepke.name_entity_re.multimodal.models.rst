Models
======

.. toctree::
   :maxdepth: 4

   deepke.name_entity_re.multimodal.models.clip

deepke.name\_entity\_re.multimodal.models.IFA\_model module
-----------------------------------------------------------

.. automodule:: deepke.name_entity_re.multimodal.models.IFA_model
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.multimodal.models.modeling\_IFA module
--------------------------------------------------------------

.. automodule:: deepke.name_entity_re.multimodal.models.modeling_IFA
   :members:
   :undoc-members:
   :show-inheritance:

