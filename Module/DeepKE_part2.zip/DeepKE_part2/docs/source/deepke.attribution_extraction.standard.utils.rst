Utils
=====


deepke.attribution\_extraction.standard.utils.ioUtils module
------------------------------------------------------------

.. automodule:: deepke.attribution_extraction.standard.utils.ioUtils
   :members:
   :undoc-members:
   :show-inheritance:

deepke.attribution\_extraction.standard.utils.nnUtils module
------------------------------------------------------------

.. automodule:: deepke.attribution_extraction.standard.utils.nnUtils
   :members:
   :undoc-members:
   :show-inheritance:

