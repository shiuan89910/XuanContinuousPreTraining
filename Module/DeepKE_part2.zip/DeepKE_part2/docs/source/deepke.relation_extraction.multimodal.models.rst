Models
======


.. toctree::
   :maxdepth: 4

   deepke.relation_extraction.multimodal.models.clip


deepke.relation\_extraction.multimodal.models.IFA\_model module
---------------------------------------------------------------

.. automodule:: deepke.relation_extraction.multimodal.models.IFA_model
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.multimodal.models.modeling\_IFA module
------------------------------------------------------------------

.. automodule:: deepke.relation_extraction.multimodal.models.modeling_IFA
   :members:
   :undoc-members:
   :show-inheritance:
