Dataset
=======

deepke.relation\_extraction.few\_shot.dataset.base\_data\_module module
-----------------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.dataset.base_data_module
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.few\_shot.dataset.dialogue module
-------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.dataset.dialogue
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.few\_shot.dataset.processor module
--------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.dataset.processor
   :members:
   :undoc-members:
   :show-inheritance:
