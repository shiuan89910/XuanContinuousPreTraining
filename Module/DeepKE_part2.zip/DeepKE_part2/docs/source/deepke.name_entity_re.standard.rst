Standard
========

.. toctree::
   :maxdepth: 4

   deepke.name_entity_re.standard.models
   deepke.name_entity_re.standard.tools
