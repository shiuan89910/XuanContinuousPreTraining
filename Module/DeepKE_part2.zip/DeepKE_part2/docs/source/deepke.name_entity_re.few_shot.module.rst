Module
======

deepke.name\_entity\_re.few\_shot.module.datasets module
--------------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.module.datasets
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.few\_shot.module.mapping\_type module
-------------------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.module.mapping_type
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.few\_shot.module.metrics module
-------------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.module.metrics
   :members:
   :undoc-members:
   :show-inheritance:

deepke.name\_entity\_re.few\_shot.module.train module
-----------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.module.train
   :members:
   :undoc-members:
   :show-inheritance:

