import json
import csv
import argparse

# 建立解析器
parser = argparse.ArgumentParser(description='轉換JSONL檔案到CSV')
# 添加命令行參數
parser.add_argument('--jsonl_file', type=str, required=True, help='JSONL檔案的路徑')
parser.add_argument('--csv_file', type=str, required=True, help='輸出CSV檔案的路徑')
# 解析命令行參數
args = parser.parse_args()

# 使用命令行參數
jsonl_file = args.jsonl_file
csv_file = args.csv_file

# 開啟jsonl檔案並讀取資料
with open(jsonl_file, 'r', encoding='utf-8') as file:
    lines = file.readlines()

# 開啟csv檔案準備寫入
with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    # 遍歷每一行jsonl資料
    for line in lines:
        data = json.loads(line)  # 解析json資料
        text = data['text']  # 獲取文本
        labels = data.get('label', [])  # 獲取標記的label資訊，如果沒有則返回空列表
        # 遍歷每個標記，並寫入CSV
        for start, end, label in labels:
            entity = text[start:end]  # 獲取標記對應的文本
            writer.writerow([entity, label])  # 寫入CSV
