<p align="left">
    <b> <a href="https://github.com/zjunlp/DeepKE/blob/main/example/re/standard/data/README.md">English</a> | 简体中文 </b>
</p>

支持三种类型文件格式，包含json格式、xlsx格式以及csv格式。其中各个文件的格式已提供，按照所给example.*对应格式提供数据。如非csv文件，需要用到[transform_data.py](https://github.com/zjunlp/DeepKE/blob/main/src/deepke/transform_data.py)中的json2csv函数以及xlsx2csv函数将其进行转换。