import json
from collections import defaultdict, OrderedDict
from convert.converter.converter import Converter


class KGConverter(Converter):
    def __init__(self, language = "zh", NAN="NAN", prefix = ""):
        super().__init__(language, NAN, prefix)







