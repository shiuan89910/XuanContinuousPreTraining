NER = 'NER'
RE =  'RE'
SPO = 'SPO'
EE = 'EE'
EEA = 'EEA'
EET = 'EET'
KG = 'KG'
MRC = 'MRC'

