# Download DuEE Dataset

```bash
wget 120.27.214.45/Data/ee/DuEE.zip
unzip DuEE.zip
```