export class Segment {
  constructor(
    readonly id: number,
    readonly uuid: string,
    readonly label: number,
    readonly points: number[]
  ) {}
}
