export default interface LabelProps {
  id: number
  name: string
  color: string
}
