export class OptionItem {
  constructor(public page: number, public q = '', public isChecked = '') {}
}
