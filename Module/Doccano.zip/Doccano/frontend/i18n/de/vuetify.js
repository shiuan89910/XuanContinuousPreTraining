export default {
  itemsPerPageText: 'Einträge pro Seite',
  noDataAvailable: 'Keine Daten verfügbar'
}
