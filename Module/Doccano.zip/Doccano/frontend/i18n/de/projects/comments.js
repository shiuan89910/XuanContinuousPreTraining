export default {
  comments: 'Kommentare',
  removeComment: 'Entferne Kommentar',
  removePrompt: 'Sollen diese Kommentare wirklich entfernt werden?',
  commentView: 'Ansehen',
  created_at: 'Erstellt am',
  document: 'Dokument',
  send: 'Senden',
  message: 'Nachricht'
}
