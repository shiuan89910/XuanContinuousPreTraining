export default {
  fileCannotUpload:
    'Die Datei(en) konnten nicht hochgeladen werden. Vielleicht ungültiges Format.\n Bitte prüfe die verfügbaren Dateiformate und folgende Datei(en): ',
  labelCannotCreate:
    'Das Label konnte nicht erstellt werden.\n Jeder Labelname und jedes Tastenkürzel kann nur einmal vergeben werden.',
  invalidUserOrPass: 'Falscher Benutername oder falsches Passwort, oder etwas ist schief gelaufen.'
}
