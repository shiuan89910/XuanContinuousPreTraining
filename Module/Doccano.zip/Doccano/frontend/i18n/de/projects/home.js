export default {
  home: 'Startseite',
  welcome: 'Willkommen bei Doccano!',
  importData: 'Importiere einen Datensatz',
  createLabels: 'Erstelle Labels für dieses Projekt',
  addMembers: 'Mitglieder für kollaboratives Arbeiten hinzufügen',
  defineGuideline: 'Definiere einen Leitfaden für das Projekt',
  annotateDataset: 'Annotiere den Datensatz',
  viewStatistics: 'Statistiken anzeigen',
  exportDataset: 'Exportiere den Datensatz'
}
