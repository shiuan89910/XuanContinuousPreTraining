export default {
  localeCode: 'en_US'
}
