export default {
  projects: 'projects'
}
