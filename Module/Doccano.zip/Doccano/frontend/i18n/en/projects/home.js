export default {
  home: 'Home',
  welcome: 'Welcome to Doccano!',
  importData: 'Import a dataset',
  createLabels: 'Create labels for this project',
  addMembers: 'Add members for collaborative work',
  defineGuideline: 'Define a guideline for the work',
  annotateDataset: 'Annotate the dataset',
  viewStatistics: 'View statistics',
  exportDataset: 'Export the dataset'
}
