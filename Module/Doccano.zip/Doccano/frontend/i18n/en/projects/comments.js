export default {
  comments: 'Comments',
  removeComment: 'Remove Comment',
  removePrompt: 'Are you sure you want to remove these comments?',
  commentView: 'View',
  created_at: 'Created at',
  document: 'Document',
  send: 'Send',
  message: 'Message'
}
