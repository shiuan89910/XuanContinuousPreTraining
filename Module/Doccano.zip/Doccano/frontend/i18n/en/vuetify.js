export default {
  itemsPerPageText: 'Rows per Page',
  noDataAvailable: 'No data available'
}
